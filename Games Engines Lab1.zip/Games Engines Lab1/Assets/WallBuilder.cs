﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WallBuilder : MonoBehaviour {

	// Use this for initialization
	void Start () {
        Wall();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    void Wall()
    {

        float cubeWidth = 0.98f;
        float cubeHeight = 0.98f;

        GameObject cube = new GameObject();
       

        float referenceX = 0f;
        float referenceY = 0.52f;
        float referenceZ = 0f;

        for (int i = 0; i <= 5; i++)
        {
            for (int j = 0; j <= 6; j++)
            {
                Vector3 position_ = new Vector3(referenceX +
                j * cubeWidth, referenceY + i * cubeHeight, 0);
                Color newColor = new Color(Random.Range(0.0f, 1f), Random.Range(0.0f, 1f), Random.Range(0.0f, 1f));

                Rigidbody gameObjectsRigidBody = cube.AddComponent<Rigidbody>();
                gameObjectsRigidBody.mass = 1;

                cube.transform.position = position_;
                cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
                cube.GetComponent<MeshRenderer>().material.color = newColor;
            }
        }


    }


}
